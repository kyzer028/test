CHANGELOG
=========

2.2.0
-----

 * added a collection type for the I18n behavior
 * added an optional PropertyAccessorInterface parameter to ModelType and
   ModelChoiceList
 * [BC BREAK] ModelType now has a constructor

2.1.0
-----

 * added the bridge
