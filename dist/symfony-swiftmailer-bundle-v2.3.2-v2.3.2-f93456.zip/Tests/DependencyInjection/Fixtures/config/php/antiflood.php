<?php
$container->loadFromExtension('swiftmailer', array(
    'antiflood' => true
));