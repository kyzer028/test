ProxyManager Bridge
===================

Provides integration for [ProxyManager][1] with various Symfony2 components.

Resources
---------

You can run the unit tests with the following command:

    $ cd path/to/Symfony/Bridge/ProxyManager/
    $ composer.phar install --dev
    $ phpunit

[1]: https://github.com/Ocramius/ProxyManager
