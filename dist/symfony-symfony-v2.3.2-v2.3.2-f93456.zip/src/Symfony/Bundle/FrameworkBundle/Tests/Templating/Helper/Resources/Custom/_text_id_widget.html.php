<div id="container">
    <?php echo $view['form']->widget($form) ?>
</div>
