<?php
$container->loadFromExtension('swiftmailer', array());