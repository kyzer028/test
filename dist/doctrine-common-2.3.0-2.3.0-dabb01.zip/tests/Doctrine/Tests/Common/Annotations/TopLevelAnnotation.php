<?php

use Doctrine\Common\Annotations\Annotation;

/** @Annotation */
class TopLevelAnnotation extends Annotation
{
}
