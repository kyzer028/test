## 2.0.0 (2013-04-06)

* BC BREAK the env map has been changed, inverting the keys and the values. Refs #14

## 1.0.0 (2013-04-06)

Initial release of the library.
