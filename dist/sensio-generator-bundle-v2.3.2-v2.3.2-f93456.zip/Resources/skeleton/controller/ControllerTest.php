<?php

namespace {{ namespace }}\Tests\Controller;

{% block use_statements %}
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;
{% endblock use_statements %}

{% block class_definition %}
class {{ controller }}ControllerTest extends WebTestCase
{% endblock class_definition %}
{
{% block class_body %}
{% for action in actions %}
    public function test{{ action.basename|capitalize }}()
    {
        $client = static::createClient();

        $crawler = $client->request('GET', '{{ action.route }}');
    }

{% endfor -%}
{% endblock class_body %}
}
