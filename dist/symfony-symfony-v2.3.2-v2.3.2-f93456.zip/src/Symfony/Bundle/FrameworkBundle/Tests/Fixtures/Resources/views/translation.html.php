This template is used for translation message extraction tests
<?php echo $view['translator']->trans('new key') ?>
