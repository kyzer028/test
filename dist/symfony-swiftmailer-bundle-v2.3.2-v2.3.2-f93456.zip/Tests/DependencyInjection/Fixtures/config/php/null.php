<?php
$container->loadFromExtension('swiftmailer', array(
    'transport' => null
));