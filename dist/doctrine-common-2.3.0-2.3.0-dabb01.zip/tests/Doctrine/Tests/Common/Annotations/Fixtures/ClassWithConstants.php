<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures;

class ClassWithConstants
{

    const SOME_VALUE = 'ClassWithConstants.SOME_VALUE';
    const SOME_KEY   = 'ClassWithConstants.SOME_KEY';
}